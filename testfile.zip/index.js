const {funcioutil}=require('./util.js');
//import mercadopago from 'mercadopago';
const mercadopago =require('mercadopago');
console.log(mercadopago)
exports.handler = async (event) => {
    // TODO implement
    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from Lambda!'+funcioutil()),
    };
    return response;
};
