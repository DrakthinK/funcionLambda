exports.funcioutil=()=>{

  return 'xd'; 
  }